#include <stdio.h>

#define SIZE 80

struct student{
	char am[SIZE];
	char name[SIZE];
	char last_name[SIZE];
	char fathers_name[SIZE];
	char mothers_name[SIZE];
	char adress[SIZE];
	char phone_number[SIZE];
	char mobile_number[SIZE];
	char lesson[SIZE]; 
};

typedef struct student RECORD;

void read_record(RECORD *p);
void print_record(RECORD p);

main()
{
	RECORD d1,d2;
	
	printf("Add 1st student: ");
	read_record(&d1);
	
	printf("Add 2d student: ");
	read_record(&d2);
	
	printf("Students: ");
	print_record(d1);
	print_record(d2);
	
}

void read_record(RECORD *p)
{
	printf("\nPress the AM: ");
	scanf("%s",p->am);
	
	printf("Press the Name: ");
	scanf("%s",p->name);
	//gets(RECORD.name);
	
	printf("Press the Last Name: ");
	scanf("%s",p->last_name);
	
	printf("Press the fathers Name: ");
	scanf("%s",p->fathers_name);
	
	printf("Press the mothers Name: ");
	scanf("%s",p->mothers_name);
	
	printf("Press the Adress: ");
	scanf("%s",p->adress);
	
	printf("Press the Phone Number: ");
	scanf("%s",p->phone_number);
	
	printf("Press the mobile Number: ");
	scanf("%s",p->mobile_number);
	
	printf("Press the Lesson: ");
	scanf("%s",p->lesson);
	
	
}

void print_record(RECORD x)
{
	
	printf("%s %s %s %s %s %s %s %s %s\n\n",x.am, x.name, x.last_name, x.fathers_name,x.mothers_name, x.adress, x.phone_number, x.mobile_number, x.lesson);
}
