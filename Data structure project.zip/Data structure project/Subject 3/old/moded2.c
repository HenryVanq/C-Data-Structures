#include <stdio.h>
#include <stdlib.h>

#define SIZE 80

struct student{													//kataskevi tis domis (struct) me ta stixia
	char am[SIZE];
	char name[SIZE];
	char last_name[SIZE];
	char fathers_name[SIZE];
	char mothers_name[SIZE];
	char adress[SIZE];
	char phone_number[SIZE];
	char mobile_number[SIZE];
	char lesson[SIZE]; 
	int mathima;
};


typedef struct student RECORD;									//Orismos sinonimou sto struct, me onoma RECORD

void read_record(RECORD *p);									//Sinartiri pou diavazi apo to xristi ta stixia
void print_record(RECORD x);									//Sinartiri pou ektiponi ston xristi ta stixia
void mathimata(RECORD x);										//Sinartisi pou metrai ton arithmo ton fititon pou epileksan kapio mathima


void main()
{
	RECORD *pinakas;
	int i,N,j;
	
	//O xristis bori na epileksi mono times anamesa sto 1 ke sto 50
	
	do
	{
	printf("Dose to plithos ton fititon: \n");
	scanf("%d", &N);
	}
	while(N<=0 || N>50);
	
	
	
	//Dinamiki desmefsi mnimis gia ton pinaka simfona me ton arithmo ton fititon pou edose o xristis
	
	pinakas=malloc(sizeof(RECORD)*N);
	if(!pinakas)													//An den bori na desmefsi mnimi tote bgazi to akoloutho minima ke to programma termatizi
	{
		printf("adinamia desmefsis mnimis");
		exit(0);
	}
	

	for (i=0; i<N; i++)												//Diavazma ton dedomenon ton stiymiotipon
	{
		printf("\n%do atomo:\n",i+1);
		read_record(&pinakas[i]);
	}
	
	for (i=0; i<N; i++)												//EKtiposi ton stiymiotipon
		print_record(pinakas[i]);
	
	
	printf("\n\nWould you like to see how many students choose a specific lesson? ([1] = yes [2] = no)\n>");
	scanf("%d",&j);
	
	do
	{
		if(j==2){													//An o xristis dosi tin timi 2
			exit(0);	}											//To proggrama termatizi
		else {														//Alios
			mathimata(pinakas[i]);									//Trexi tin sinartisi mathimata
		}
	}
	while(j==1 || j==2);
		   
	   
	free(pinakas);													//Apeleftherosi tis mnimis tou pinaka
}




//Sinartiri pou diavazi apo to xristi ta stixia


void read_record(RECORD *p)											
{
	printf("\nPress the AM: ");
	scanf("%s",p->am);
	
	printf("Press the Name: ");
	scanf("%s",p->name);
	
	printf("Press the Last Name: ");
	scanf("%s",p->last_name);
	
	printf("Press the Fathers Name: ");
	scanf("%s",p->fathers_name);
	
	printf("Press the Mothers Name: ");
	scanf("%s",p->mothers_name);
	
	printf("Press the Adress: ");
	scanf("%s",p->adress);
	
	printf("Press the Phone Number: ");
	scanf("%s",p->phone_number);
	
	printf("Press the Mobile Number: ");
	scanf("%s",p->mobile_number);
	
	printf("Press the Lesson (Diakrita_mathimatika / Idika_kefalea_mathimatikon / Logikos_programmatismos): ");
	scanf("%s",p->lesson);
	
	printf("\n============================= \n");
}


//Sinartisi pou metrai ton arithmo ton fititon pou epileksan kapio mathima

void mathimata(RECORD x)
{
	int mathima,counter,k;
	printf("\nWhich lesson would you like to see? [1]Diakrita mathimatika [2] Idika kefalea mathimatikon [3] Logikos programmatismos\n>");
	scanf("%d",&x.mathima);	
	if(x.mathima==1){											//Ean o xristis zitisi na di gia ta diakrita ma8imatika
		for(k=0; k<SIZE; k++)										//gia kathe eggrafi fititi
		{
			if(pinakas.lesson=Diakrita_mathimatika)				//an i stili lesson exi tin timi Diakrita_mathimatika
			{
				counter++;										//Afksise ton couner kata 1, gia na gini i metrisi
			}
		}
		printf("\n\n%d students chose Diakrita mathimatika",counter);	
	}else if(x.mathima==2){										//Ean o xristis zitisi na di gia ta idika kefalea mathimatikon
		for(k=0; k<N; k++)										//gia kathe eggrafi fititi
		{
			if(pinakas.lesson=Idika_kefalea_mathimatikon)		//an i stili lesson exi tin timi Idika kefalea mathimatikon		
			{
				counter++;										//Afksise ton couner kata 1, gia na gini i metrisi
			}
		}
		printf("\n\n%d students chose Idika kefalea mathimatikon",counter);
	}else{														//Ean o xristis zitisi na di gia ton logiko programatizmo
		for(k=0; k<N, k++)										//gia kathe eggrafi fititi
		{
			if(pinakas.lesson=Logikos_programmatismos)			//an i stili lesson exi tin timi Diakrita_mathimatika
			{
				counter++;										//Afksise ton couner kata 1, gia na gini i metrisi
			}
		}
		printf("\n\n%d students chose Logikos programmatismos",counter);
	}
}
	
	
	
//Sinartisi pou ektiponi ta stixia ston xristi


void print_record(RECORD x)
{
	printf("%s %s %s %s %s %s %s %s %s\n\n",x.am, x.name, x.last_name, x.fathers_name,x.mothers_name, x.adress, x.phone_number, x.mobile_number, x.lesson);
}
