#include <stdio.h>
#define max 50000
int main(void)
{
	int arfit,i,run,standby,counter=0;
	char mathima1,sira[max],stop;
	printf("An thelis na prosthesis fititi pata to 1 \nAn thelis na dis posi fitites exun epileksi kapio mathima pata to 2\n\n");
	scanf("%d",&run);
	if (run<1 || run>2) 
		{
		printf("Den einai apodekti i timi %d",run);
		scanf("%d",&standby);
		}
	else if (run == 1)
		{
		printf("\n\nDose ton arithmo ton fititon:\n");
		scanf("%d",&arfit);
		for(i=0; i<arfit; i++)
			{
				FILE *fp;
				char mitroo[9],eponimo[20],onoma[20],patronimo[20],mitronimo[20],diefthinsi[40],mathima[50],stathero[10],kinito[10];
				printf("\n\n\nDose ta stixia \n Mitroo:");
				scanf("%s",mitroo);
				printf("\n Eponimo:");
				scanf("%s",eponimo);
				printf("\n Onoma:");
				scanf("%s",onoma);
				printf("\n patronimo:");
				scanf("%s",patronimo);
				printf("\n mitronimo:");
				scanf("%s",mitronimo);
				printf("\n diefthinsi:");
				scanf("%s",diefthinsi);
				printf("\n mathima:");
				scanf("%s",mathima);
				printf("\n stathero:");
				scanf("%s",stathero);
				printf("\n kinito:");
				scanf("%s",kinito);

				//eggrafi sto arxio
				fp=fopen("eggrafima.csv","a");
				//chmod 777 eggrafima.csv;
				fprintf(fp,"\n%s, %s, %s, %s, %s, %s, %s, %s, %s",mitroo,eponimo,onoma,patronimo,mitronimo,diefthinsi,mathima,stathero,kinito);
				fclose(fp);
				printf("\n\nI eggrafi prostethike sto arxio");

				//diavazma ton eggrafon ap to arxio
				fp=fopen("eggrafima.txt","r");
				fscanf(fp,"%s %s %s %s %s %s %s %s %s",mitroo,eponimo,onoma,patronimo,mitronimo,diefthinsi,mathima,stathero,kinito);
	   	 		printf("\n Mitroo: %s \n eponimo: %s \n onoma: %s \n patronimo: %s \n mitronimo: %s \n diefthinsi: %s \n mathima: %s \n stathero: %s \n kinito: %s",mitroo,eponimo,onoma,patronimo,mitronimo,diefthinsi,mathima,stathero,kinito);
				fclose(fp);	  
			}
		}
	else
		{
		printf("\n\ngia pio mathima thelis na dis ton arithmo fititon pou to dilosan?\n\n");
		FILE *pf;
		scanf("%s",mathima1);
		pf=fopen("eggrafima.csv","r");
		// evala fgets adi gia fscanf
		while (fgets(sira, max, pf) != NULL)
		{
			if (strcmp(sira,"mathima1") == 0)
			{
				++counter;
			}
		}
		printf ("Afto to mathima exi epilexthi apo %d fitites",counter);
		fclose(pf);
		scanf("%s",stop);
		return counter;
		}	
}
