/* linked_list.c: Kwdikas tis vivliothikis sindedemenis listas */
#include <stdio.h>
#include <stdlib.h>


typedef int elem;          // typos dedomenwn listas. synonimo ston int

struct node{			   /* Typos komvou listas */
   elem data; 			   /* dedomena */
   struct node *next;      /* epomenos */
};

typedef struct node LIST_NODE; /* Sinwnimo tou komvou listas */
typedef struct node *LIST_PTR; /* Sinwnimo tou deikti komvou */

// h lista tha einai enas deiktis se komvo listas (tha dilonetai sth main)

void LL_init(LIST_PTR *head);
int LL_empty(LIST_PTR head);
elem LL_data(LIST_PTR p);
int LL_insert_start(LIST_PTR *head,elem x);
int LL_insert_after(LIST_PTR p,elem x);
int LL_delete_start(LIST_PTR *head, elem *x);
int LL_delete_after(LIST_PTR prev, elem *x);
void LL_print(LIST_PTR head);
void LL_destroy(LIST_PTR *head);

main()
{
	int elem;
	LIST_PTR head,prev,current;
	
	LL_init(&head);
	
	/* Eisagwgi tou "1" */
	LL_insert_start(&head, 1);
	
	printf("\n");
	LL_print(head);
	
	/* Eisagwgi tou "2" stin arxi */
	LL_insert_start(&head, 2);
	
	printf("\n");
	LL_print(head);
	
	/* Eisagwgi tou "3" meta to 1o stoixeio */
	LL_insert_after(head, 3);
	
	printf("\n");
	LL_print(head);
	
	/* Eisagwgi tou "4" meta to 2o stoixeio */
	LL_insert_after(head->next, 4);
	
	printf("\n");
	LL_print(head);
	
	/* Eisagwgi tou "5" stin arxi */
	LL_insert_start(&head, 5);
	
	printf("\n");
	LL_print(head);
	
	/* Eisagwgi tou "6" stin arxi */
	LL_insert_start(&head, 6);
	
	printf("\n");
	LL_print(head);
	
	/* Eisagwgi tou "7" sto telos */
	current=head;
	prev=current;
	while(current->next!=NULL)
	{
		prev=current;
		current=current->next;
	}
	LL_insert_after(prev, 7);

	printf("\n");
	LL_print(head);

	/* Diagrafi tou 1ou stoixeiou */
	LL_delete_start(&head,&elem);
	
	printf("\n");
	LL_print(head);

	/* Diagrafi tou teleytaiou stoixeiou */
	current=head;
	while(current->next!=NULL)
	{
		prev=current;
		current=current->next;
	}
	LL_delete_after(prev,&elem);
	
	printf("\n");
	LL_print(head);

	LL_destroy(&head);
}


/* LL_init(): arxikopoiei tin lista */
// h synartisi tha kanei to head na einai isi me to NULL, to LIST_PTR einai deikths se komvo
//epeidi stin arxi to head mporei na exei skoupidia, theloume h timi tou head na allazei
// ara pernaw san orisma th head  h opoio typou LIST_PTR by reference
// etsi to *head=NULL  tha synexisei na ifistatai kai meta tin klisi ths synartisis

void LL_init(LIST_PTR *head)
{
	*head=NULL;
}

/* LL_empty(): epistrefei TRUE/FALSE
 *          analoga me to an i lista einai adeia */
int LL_empty(LIST_PTR head)
{
	return head == NULL;
}

/* LL_data(): epistrefei ta dedomena tou komvou
			  pou deixnei o deiktis p */
elem LL_data(LIST_PTR p)
{
	return p->data;
}

//eisagei to sxtoixeio x sthn arxh ths listas
// prota prota vazoume san orisma to head kai to pernaw meso deikti gia na allaksei h timi toy kai element x to stoixeio poy tha eisagoume
int LL_insert_start(LIST_PTR *head,elem x)
{
	//����� ������� �������� ����� ��� ��� ��� �����
	LIST_PTR newnode; 
	
	newnode=(LIST_NODE *)malloc(sizeof(LIST_NODE));
	if (!newnode)
	{
		printf("Adynamia desmeusis mnimis");
		return 0;
	}
	newnode->data=x; // �� data ���� ��� newnode=me to stoixeio

	newnode->next=*head; // ekei poy dexnei to *head deixnei kai o newnode kai amesw meta to *head na deixnei sto newnode
	*head=newnode;
	return 1;
}

/* LL_insert_after(): Eisagei to stoixeio x
			meta to stoixeio pou deixnei o p */
 //den pairnei orisma mesw anaforas giati etsi tha allaksei
int LL_insert_after(LIST_PTR p,elem x)
{
	LIST_PTR newnode;
	
	newnode=(LIST_NODE *)malloc(sizeof(LIST_NODE));
	if (!newnode)
	{
		printf("Adynamia desmeusis mnimis");
		return 0;
	}
	newnode->data=x;
	
	newnode->next=p->next;
	p->next=newnode;
	return 1;
}

/* LL_delete_start(): Diagrafei ton komvo poy deixnei 
	i kefali tis listas */
int LL_delete_start(LIST_PTR *head, elem *x) // by refernece epistrefw tin timi
{
	LIST_PTR current;
	
	if (*head==NULL)
		return 0;
		
	current=*head;
	*x=current->data;
	
	(*head)=(*head)->next;
	free(current);
	return 1;
}

/* LL_delete_after(): Diagrafei ton epomeno tou 
				komvou poy deixnei o prev */
int LL_delete_after(LIST_PTR prev, elem *x)
{
	LIST_PTR current;
	
	if (prev->next==NULL)
		return 0;
		
	current=prev->next;
	*x=current->data;
	
	prev->next=current->next;
	free(current);
	return 1;
}

/* LL_print(): Typwnei ta periexomena mias
				syndedemenis listas	 */

void LL_print(LIST_PTR head)
{
	LIST_PTR current;
	
	current=head;
	while(current!=NULL)
	{
		printf("%d ",current->data);
		current=current->next;
	}
}

/* LL_destroy(): Apodesmeyei to xwro poy exei 
				desmeusei i lista	 */

void LL_destroy(LIST_PTR *head)
{
	LIST_PTR ptr;
	
	while (*head!=NULL)
	{
		ptr=*head;
		*head=(*head)->next;
		free(ptr);
	}
}
