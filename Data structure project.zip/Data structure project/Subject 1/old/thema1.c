#include<stdio.h>
#define SIZE 10

void main()
{
 float a[SIZE],b[SIZE],c[SIZE];
 int i;
 
 printf("1: Please insert the elements of the table B. \n\n");
 
 for(i=0; i<10; i++)
 {
	printf("position %d:\t", i+1);
	scanf("%f", &b[i]);
 }

 printf("\n");
 
 printf("2: Please insert the elements of the table C. \n\n");
 for(i=0; i<10; i++)
 {
	printf("position %d:\t", i+1);
	scanf("%f", &c[i]);
 }

 printf("\n");
 printf("Table A. \n\n");
 
 for(i=0; i<10; i++)
 {
	a[i] = b[i] + c[i];
	printf("[%.3f]\t", a[i]);
 }
 
}
 /*for(i=0; i<10; i++) 
 {
	printf("%.3f" " ",a[i]);*/
 
//printf("I prosthesi ton pinakon einai to a:\n\n %f",a[10]);
 
